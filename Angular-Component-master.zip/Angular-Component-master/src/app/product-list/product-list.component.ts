import { Component, OnInit } from "@angular/core";
import { Product } from "../Product";
import { ListProduct } from "../ListProduct";

@Component({
  selector: "app-product-list",
  templateUrl: "./product-list.component.html",
  styleUrls: ["./product-list.component.css"]
})
export class ProductListComponent implements OnInit {
  constructor() {}

  ngOnInit() {}

  data = ListProduct;
  prodetail: Product;

  xoasp(pro: Product) {
    this.data = this.data.filter(function(value) {
      return value !== pro;
    });
  }

  xem(pr): void {
    this.prodetail = pr;
  }

  thoat(): void {
    this.prodetail = null;
  }
}
