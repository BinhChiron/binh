import { Product } from './Product';

export const ListProduct: product[] = [
  {
    id: 1,
    name: "sản phẩm 1",
    price: 100
  },
  {
    id: 2,
    name: "sản phẩm 2",
    price: 200
  },
  {
    id: 3,
    name: "sản phẩm 3",
    price: 200
  },
  {
    id: 4,
    name: "sản phẩm 4",
    price: 200
  },
  {
    id: 5,
    name: "sản phẩm 5",
    price: 200
  },
  {
    id: 6,
    name: "sản phẩm 6",
    price: 200
  },
  {
    id: 7,
    name: "sản phẩm 7",
    price: 200
  },
  {
    id: 8,
    name: "sản phẩm 8",
    price: 200
  },
  {
    id: 9,
    name: "sản phẩm 9",
    price: 200
  },
  {
    id: 10,
    name: "sản phẩm 10",
    price: 200
  }
];
